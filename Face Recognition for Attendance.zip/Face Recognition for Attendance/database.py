import pymysql

conn= pymysql.connect(host="localhost",database="bep",user="root", password="")

sql='select * from attendance_of_july;'

cursor=conn.cursor()
countrow=cursor.execute(sql)
print("number of rows:",countrow)
cursor.execute(sql)

data=cursor.fetchall()
print(data)
list=['deepty','poly','eva']

#sql1='insert into attendance_of_july(name)values(?);',[(x,) for  x in list]
#cursor.executemany('insert into attendance_of_july(name)values(%s);',[(x,) for  x in list])
#sql2='alter table attendance_of_july add day_%s boolean(2);'
i=1
day='day_'+str(i)

#days= day.replace("''","")
#print(day)
cursor.execute('alter table attendance_of_july add'+ day+ boolean default false not null;',day)
i=i+1
