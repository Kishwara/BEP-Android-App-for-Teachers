package com.hackathon.bep;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Student0 extends AppCompatActivity {
    RadioGroup radiogroup1,radiogroup2;
    int result1;
    int result2;
    int result3;
    int result4;

    Button btnresult;
    int finalResult1;
    int finalResult2;
    int finalResult3;
    int finalResult4;

    TextView textView1;
    TextView textView2;
    TextView textView3;
    TextView textView4;
    String evaluation1=" ";
    String evaluation2=" ";
    String evaluation3=" ";
    String evaluation4=" ";
    private DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student0);
        btnresult=(Button)findViewById(R.id.btn1);
        btnresult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(result1==1){
                    finalResult1=5;
                }
                else{
                    finalResult1=4;
                }
                if(result2==1){
                    finalResult2=5;
                }
                else{
                    finalResult2=4;
                }
                if(result3==1){
                    finalResult3=5;
                }
                else{
                    finalResult3=4;
                }
                if(result4==1){
                    finalResult4=5;
                }
                else{
                    finalResult4=4;
                }


                evaluation1=Integer.toString(finalResult1);
                evaluation2=Integer.toString(finalResult2);
                evaluation3=Integer.toString(finalResult3);
                evaluation4=Integer.toString(finalResult4);

                databaseReference= FirebaseDatabase.getInstance().getReference("Evaluation");
                String uploadId=databaseReference.push().getKey();
                Evaluation evaluation=new Evaluation(evaluation1,evaluation2,evaluation3,evaluation4);

                //databaseReference.child("raju").setValue(evaluation).;


                databaseReference.child("raju").setValue(evaluation)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(Student0.this,"complete!",Toast.LENGTH_LONG).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                // Write failed
                                // ...
                                Toast.makeText(Student0.this,"Failed!",Toast.LENGTH_LONG).show();
                            }
                        });

            }
        });
    }
    public void onclickButtonClicked(View view){
        boolean checked=((RadioButton) view).isChecked();
        if(view.getId()==R.id.radiolinguistic1){
            result1=1;

        }
        else if(view.getId()==R.id.radiolinguistic2){
            result1=2;

        }

    }
    public void onclickButtonClicked1(View view){
        boolean checked=((RadioButton) view).isChecked();
        if(view.getId()==R.id.radiomath1){
            result2=1;

        }
        else if(view.getId()==R.id.radiomath2){
            result2=2;

        }

    }


    public void onclickButtonClicked2(View view){
        boolean checked=((RadioButton) view).isChecked();
        if(view.getId()==R.id.radioco1){
            result3=1;

        }
        else if(view.getId()==R.id.radioco2){
            result3=2;

        }

    }


    public void onclickButtonClicked3(View view){
        boolean checked=((RadioButton) view).isChecked();
        if(view.getId()==R.id.radiohelp1){
            result4=1;

        }
        else if(view.getId()==R.id.radiohelp2){
            result4=2;

        }

    }


}
