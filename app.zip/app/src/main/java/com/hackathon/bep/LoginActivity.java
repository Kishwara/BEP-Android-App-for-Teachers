package com.hackathon.bep;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private EditText editEmail;
    private EditText editPass;
    private Button loginbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        editEmail=(EditText)findViewById(R.id.email);
        editPass=(EditText)findViewById(R.id.password);
        loginbtn=(Button)findViewById(R.id.login);

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email= editEmail.getText().toString().trim();
                String pass= editEmail.getText().toString().trim();

                if(email!=null && pass!=null){
                    Intent intent=new Intent(getApplicationContext(),MainMenu.class);
                    startActivity(intent);

                }
                else{
                    Toast.makeText(getApplicationContext(),"please fill the Id and password  field...",Toast.LENGTH_LONG).show();
                }
            }
        });


    }
}
