package com.hackathon.bep;



public class Evaluation {

    private String linguistic;
    private String math;
    private String co_curricular;
    private String help;

    public Evaluation(String linguistic, String math, String co_curricular, String help) {
        this.linguistic = linguistic;
        this.math = math;
        this.co_curricular = co_curricular;
        this.help = help;
    }

    public String getMath() {
        return math;
    }

    public void setMath(String math) {
        this.math = math;
    }

    public String getCo_curricular() {
        return co_curricular;
    }

    public void setCo_curricular(String co_curricular) {
        this.co_curricular = co_curricular;
    }

    public String getHelp() {
        return help;
    }

    public void setHelp(String help) {
        this.help = help;
    }

    public String getLinguistic() {
        return linguistic;
    }

    public void setLinguistic(String linguistic) {
        this.linguistic = linguistic;
    }
}
